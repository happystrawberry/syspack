import _ from "lodash";

document.getElementById("button1").addEventListener("click", function () {
  const el = document.getElementById("header");
  el.innerHTML = "Check cx accounts";

  const listItems = ["item1", "item2", "item3"];
  const ul = document.getElementById("cxList");
  _.forEach(listItems, function (item) {
    const tempEl = document.createElement("li");
    tempEl.innerHTML = item;
    ul.appendChild(tempEl);
  });
});
